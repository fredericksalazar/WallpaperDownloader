/**
 * Copyright 2016-2017 Eloy García Almadén <eloy.garcia.pca@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package es.estoes.wallpaperDownloader.window;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;

import es.estoes.wallpaperDownloader.changer.LinuxWallpaperChanger;
import es.estoes.wallpaperDownloader.util.WDUtilities;
import es.estoes.wallpaperDownloader.util.WallpaperListRenderer;

public class ChooseWallpaperWindow extends JFrame {

	// Constants
	private static final long serialVersionUID = 8790655483965002934L;
	
	public static JLabel lblTotaleWallpapers;

	// Attributes
	private JButton btnRemoveWallpaper;
	private JButton btnPreviewWallpaper;
	private JButton btnSetDskWallpaper;
	private JButton btnClose;
	private JScrollPane wallpapersScrollPanel;
	private JList<Object> wallpapersList;
	private JButton btnBackWallpapers;
	private JButton btnForwardWallpapers;
	private JLabel lblFirstWallpaper;
	private JLabel lblLastWallpaper;
	
	// Methods
	/**
	 * Constructor
	 */
	public ChooseWallpaperWindow() {
		// DISPOSE_ON_CLOSE for closing only this frame instead of the entire application
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Choose wallpaper");
		setBounds(100, 100, 774, 621);
		getContentPane().setLayout(null);
		
		// Centering window
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Dimension screenSize = toolkit.getScreenSize();
		int x = (screenSize.width - getWidth()) / 2;
		int y = (screenSize.height - getHeight()) / 2;
		setLocation(x, y);
		
		JLabel lblWallpapers = new JLabel("Wallpapers");
		lblWallpapers.setBounds(12, 12, 151, 15);
		getContentPane().add(lblWallpapers);
		
		lblTotaleWallpapers = new JLabel("");
		lblTotaleWallpapers.setBounds(163, 12, 70, 15);
		getContentPane().add(lblTotaleWallpapers);
		
		wallpapersScrollPanel = new JScrollPane();
		wallpapersScrollPanel.setBounds(12, 33, 688, 420);
		getContentPane().add(wallpapersScrollPanel);
		
		wallpapersList = new JList<Object>();
		wallpapersScrollPanel.setViewportView(wallpapersList);

		btnRemoveWallpaper = new JButton();
		
		try {
			Image img = ImageIO.read(getClass().getResource("/images/icons/delete_24px_icon.png"));
			btnRemoveWallpaper.setIcon(new ImageIcon(img));
			btnRemoveWallpaper.setToolTipText("Delete selected wallpaper");
			btnRemoveWallpaper.setBounds(713, 182, 34, 33);
		} catch (IOException ex) {
			btnRemoveWallpaper.setText("Delete");
			btnRemoveWallpaper.setBounds(713, 182, 34, 33);

		}
		getContentPane().add(btnRemoveWallpaper);

		btnPreviewWallpaper = new JButton();

		try {
			Image img = ImageIO.read(getClass().getResource("/images/icons/view_24px_icon.png"));
			btnPreviewWallpaper.setIcon(new ImageIcon(img));
			btnPreviewWallpaper.setToolTipText("Preview wallpaper");
			btnPreviewWallpaper.setBounds(712, 222, 34, 33);
		} catch (IOException ex) {
			btnPreviewWallpaper.setText("Preview wallpaper");
			btnPreviewWallpaper.setBounds(1064, 120, 34, 33);
		}
		getContentPane().add(btnPreviewWallpaper);

		btnSetDskWallpaper = new JButton();

		try {
			Image img = ImageIO.read(getClass().getResource("/images/icons/desktop_24px_icon.png"));
			btnSetDskWallpaper.setIcon(new ImageIcon(img));
			btnSetDskWallpaper.setToolTipText("Set selected wallpaper");
			btnSetDskWallpaper.setBounds(712, 262, 34, 33);
		} catch (IOException ex) {
			btnSetDskWallpaper.setText("Set wallpaper");
			btnSetDskWallpaper.setBounds(712, 161, 34, 33);
		}
		// This button only will be available for those desktops which support setting wallpapers directly
		if (WDUtilities.getWallpaperChanger().isWallpaperChangeable()) {
			getContentPane().add(btnSetDskWallpaper);			
		}
		
		btnClose = new JButton("Close");
		btnClose.setBounds(630, 561, 116, 25);
		getContentPane().add(btnClose);
		
		lblFirstWallpaper = new JLabel("1");
		lblFirstWallpaper.setBounds(331, 470, 34, 15);
		getContentPane().add(lblFirstWallpaper);
		
		JLabel lblBetween = new JLabel("--");
		lblBetween.setBounds(369, 470, 17, 15);
		getContentPane().add(lblBetween);
		
		lblLastWallpaper = new JLabel("20");
		lblLastWallpaper.setBounds(413, 470, 34, 15);
		getContentPane().add(lblLastWallpaper);
		
		btnBackWallpapers = new JButton();
		
		try {
			Image img = ImageIO.read(getClass().getResource("/images/icons/left_arrow_24px_icon.png"));
			btnBackWallpapers.setIcon(new ImageIcon(img));
			btnBackWallpapers.setToolTipText("Back");
			btnBackWallpapers.setBounds(282, 465, 34, 33);
		} catch (IOException ex) {
			btnBackWallpapers.setText("Back");
			btnBackWallpapers.setBounds(282, 250, 34, 33);
		}		
		getContentPane().add(btnBackWallpapers);
		
		btnForwardWallpapers = new JButton();
		
		try {
			Image img = ImageIO.read(getClass().getResource("/images/icons/right_arrow_24px_icon.png"));
			btnForwardWallpapers.setIcon(new ImageIcon(img));
			btnForwardWallpapers.setToolTipText("Forward");
			btnForwardWallpapers.setBounds(442, 465, 34, 33);
		} catch (IOException ex) {
			btnForwardWallpapers.setText("Forward");
			btnForwardWallpapers.setBounds(442, 250, 34, 33);
		}		
		getContentPane().add(btnForwardWallpapers);
		
		// Setting up configuration
		initializeGUI();
		
		// Setting up listeners
		initializeListeners();
	}

	private void initializeGUI() {
		// ---------------------------------------------------------------------
		// Populating favorite wallpapers
		// ---------------------------------------------------------------------
		refreshWallpapers();	
	}
	
	private void initializeListeners() {
		/**
		 * btnClose
		 */
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		
		/**
		 * btnForwardFavoriteWallpapers
		 */
		btnForwardWallpapers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int firstWallpaperToDisplay = Integer.valueOf(lblLastWallpaper.getText()) + 1;
				int totalWallpapers = Integer.valueOf(lblTotaleWallpapers.getText());
				
				// It will be possible to forward the wallpapers list only if there are more wallpapers to display
				if (totalWallpapers >= firstWallpaperToDisplay) {
					int to = firstWallpaperToDisplay + 19;
					if (to > totalWallpapers) {
						to = totalWallpapers;
					}
					lblFirstWallpaper.setText(String.valueOf(firstWallpaperToDisplay));
					lblLastWallpaper.setText(String.valueOf(to));
					refreshWallpapers();
				}
			}
		});
		
		/**
		 * btnBackFavoriteWallpapers
		 */
		btnBackWallpapers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int firstWallpaperToDisplay = Integer.valueOf(lblFirstWallpaper.getText()) - 20;
				int totalWallpapers = Integer.valueOf(lblTotaleWallpapers.getText());
				
				// It will be possible to backward the wallpapers list only if there are wallpapers to display
				if (firstWallpaperToDisplay > 0) {
					int from = firstWallpaperToDisplay;
					int to = from + 19;
					if (to > totalWallpapers) {
						to = totalWallpapers;
					}
					lblFirstWallpaper.setText(String.valueOf(from));
					lblLastWallpaper.setText(String.valueOf(to));
					refreshWallpapers();
				}
			}
		});
		
		/**
		 * btnRemoveFavoriteWallpaper
		 */
		btnRemoveWallpaper.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Get the selected wallpapers
				List<Object> wallpapersSelected =vate JLabel lblrs likable. JLabpapers()s
			tText(Object> wallpapersSex).getAbsolupapers = new ArratText(Opapers().util.It		List<Object> wallpapersSe.util.Itlected =vate papersSe.iutil.Itpapers()	    	wject> wallpapersSe.util.It.hasNr.getTepers) {n(new Imacted =vatepapersSe.crVers(n(new Ima)bject> wallpapersSe.util.IteratoDaemon();ject> wallpapersSex).getAbsoluPane().add(walpapersSe.crV (this.criIOExcetText())
							if (WDUtilr		btnRemoveWalwject> wallpapersSex).getAbsolu,rror = BooleaText())
					refreshWallpapers(	}
			}
		});
		
		/**
		dd(btnPRemoveFavoriteWallpaper
		 */			btnPreviewWallpaper.addActionListener(new ActionListener() {
			public void actionPerformed(ActionErmed(Actiot arg0) {
				// Get the selected wallpapers
				List<Object> wallpapersSelected =vate JLabel lblrs likable. JLabpapers()s
			tText(Object> wallpapersSex).getAbsolupapers = new ArratText(Opapers().util.It		List<Object> wallpapersSe.util.Itlected =vate papersSe.iutil.Itpapers()	    	wject> wallpapersSe.util.It.hasNr.getTepers) {n(new Imacted =vatepapersSe.crVers(n(new Ima)bject> wallpapersSe.util.IteratoDaemon();ject> wallpapersSex).getAbsoluPane().add(walpapersSe.crV (this.criIOExcetText())
					rg0) {
	Open startpext("Prering win();
    a.awt.Comom twt.Comors(a.awt.Com)nErmed(Actioel lbgetResrsion")))))))tends J).add(walDialogMlpaperWrs(tends ) swing.SwingUtilass(oot(m twt.ComText())			btnPreviewWallpaperWpext("PlpaperWrsers 			btnPreviewWallpaperwject> wallpapersSex).getAbsolupaper0),onizlic ChooseWallpaper)J).add(walDialogMlpaperText())pext("PlpaperlPanelbe pocancel(
 {
	  		}
	 if i * Sbu* alonget inlasma vers9)ersiotartpext("Prering  i *not pa
		Seltop --ly
 {
	  		}			i *ne = pary			i			rathe hi *ering  in ordallpappa
		atheritsom twt.Coms
 {
	  tly
		if (WDUtilities.getWallpaperChareturn inofpublic LinuxWallpaperCbled()+ 19;
			((ublic LinuxWallpaperCb		if (WDUtilities.getWallpaperCha) (this.getDesktopEnvironstannment(WDUtilities.Dled()+ 19;)pext("PlpaperlPanScree1023, 767sage+ 19;)d()+ 19;}d()+ 19;
				}
			}
		}); 
		
		//**
		SeDsbtnBackFalblLastWallormed( Lg up listen per
	)))))));
			btnSetDskWallpaper.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Get the selected wallpapers
				List<Object> wallpapersSelected =vate JLabel lblrs likable. JLabpapers()s
			tText(Object> wallpapersSex).getAbsolupapers = new ArratText(Opapers().util.It		List<Object> wallpapersSe.util.Itlected =vate papersSe.iutil.Itpapers()	    	wject> wallpapersSe.util.It.hasNr.getTepers) {n(new Imacted =vatepapersSe.crVers(n(new Ima)bject> wallpapersSe.util.IteratoDaemon();ject> wallpapersSex).getAbsoluPane().add(walpapersSe.crV (this.criIOExcetText())
							if (WDUtilities.getWallpaperChan void setWallject> wallpapersSex).getAbsolupaper0)apers(	}
	  		}n");
 1);
ersi			sWarn"gse({ "rawtypes", "unErrored" 		erride
	public
					refreshWallpaepersn(new Ima[]re are wallp=sh " + WDUtilitin(new ImaefreshWallp064,lay = Integer.valueOf(lblFirstWallpaper.getText1,sh " + WDUtilSORTING_MULTIPLE_DIR,sh " + WDUtilWD_ALLject>();
		wallpapersList = newlject> wallject>oader.Po
		SrJJLabpapersject> wallpapersScrollPanel.setViewportView(wallpapersL) {
	JJLab s the et the iguratted =vate JLabeseng.ListSelecti(swing.ListSelectio.MULTIPLE_INTERVAL_SELECTIONrsL) {
	JJLab hackztputl oritioa iguratted =vate JLabesen().setOritioa igu(JJLab.HORIZONTAL_WRAPrsL) {
	.
	 *4 r't allrs to dispted =vate JLabesenelbe poRowCouiro4rsL) {
	Uor cla custo =rendallpaprendallcally .Linviroalonin JJLabispted =vate JLabesenCellerListRestenelFirstWallpaperListRe(lFirstWallpaperListRe.* bu_TEXT)lpapl;
		}
	}
	
	/**
	 * This moader. startpo
		Sr whout eve     	btnsDE for     btnt undeJJLabisPath
	 */
	privateoader.Po
		SrJJLabpaepersted =vate JLabeaneevent.MouseMotionListeneevent.MouseMotionLiseption) {
   ride
	publicmvent.Mverfevent.Mous eeption) {
       tatic ();
		inRuntiXDialog();
       tatic ();
y	inRuntiYDialog();
       {
	 listrs to dla hationtead oc.awt.	i *btnt undeiutmslog();
       tatic a.awt.Rec cellrs.setlected =vate JLabel lCellrs.set(0014, 0, wal JLabel lectiotClassScreenngth(alog();
       
			cellrs.setlne()) ! && cellrs.setOutput.conationeption) {
       pted =vate JLabesenC.awt.steneC.awt.sC.awt..HANDv("XSMA_Ealog();
       }log();
      	  }

   ride
	publicmventDraggerfevent.Mous eeption) {
       	}eners(	}
	}
	
	/**
	 * This sc
					rnsDE fo	to =())condnsteating favorite wallpatop.
	 * @	to =ructor
	 */
	pivate stalic
					refreshWallOf(lbsecond								inttart () {

		
		lblTotaleWallpocess != null)");
		lblTotaleWallpapeer.setText(String.valuintt34, 33);s(	}e;
	}
}
